import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-landing-components',
  templateUrl: './landing-components.component.html',
  styleUrls: ['./landing-components.component.scss']
})
export class LandingComponentsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
