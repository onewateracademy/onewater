import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LandingComponentsRoutingModule } from './landing-components-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    LandingComponentsRoutingModule
  ]
})

export class LandingComponentsModule { }
