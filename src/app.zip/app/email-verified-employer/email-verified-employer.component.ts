import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-email-verified-employer',
  templateUrl: './email-verified-employer.component.html',
  styleUrls: ['./email-verified-employer.component.scss']
})
export class EmailVerifiedEmployerComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
