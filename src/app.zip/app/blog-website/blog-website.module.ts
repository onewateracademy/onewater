import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BlogWebsiteRoutingModule } from './blog-website-routing.module';

@NgModule({
  declarations: [
    ],
  imports: [
    CommonModule,
    BlogWebsiteRoutingModule
  ]
})

export class BlogWebsiteModule { }
