import { NgModule, OnInit } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

@NgModule({
  imports: [],
  exports: [RouterModule]
})
export class BlogWebsiteRoutingModule implements OnInit{ 
  constructor(){}
  ngOnInit(){
    
  }
}
