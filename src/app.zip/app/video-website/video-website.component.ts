import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-video-website',
  templateUrl: './video-website.component.html',
  styleUrls: ['./video-website.component.scss']
})
export class VideoWebsiteComponent implements OnInit {

  constructor() { }

  ngOnInit() {

  }

}
