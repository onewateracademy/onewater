import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-email-verified-author',
  templateUrl: './email-verified-author.component.html',
  styleUrls: ['./email-verified-author.component.scss']
})
export class EmailVerifiedAuthorComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
