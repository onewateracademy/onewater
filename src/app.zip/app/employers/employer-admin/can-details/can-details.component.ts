import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-can-details',
  templateUrl: './can-details.component.html',
  styleUrls: ['./can-details.component.scss']
})
export class CanDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
